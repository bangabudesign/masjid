export declare function setAttribute(elm: Element, attr: string, value: string | number | boolean): void;
export declare function setAttribute(elm: Element, attrs: Record<string, string | number | boolean>): void;
//# sourceMappingURL=../../../../../src/js/utils/dom/setAttribute/setAttribute.d.ts.map