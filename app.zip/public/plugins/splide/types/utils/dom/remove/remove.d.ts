/**
 * Removes the provided node from its parent.
 *
 * @param nodes - A node or nodes to remove.
 */
export declare function remove(nodes: Node | Node[]): void;
//# sourceMappingURL=../../../../../src/js/utils/dom/remove/remove.d.ts.map