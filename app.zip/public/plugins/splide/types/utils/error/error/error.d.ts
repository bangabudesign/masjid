/**
 * Displays the error message on the console.
 *
 * @param message - A message.
 */
export declare function error(message: string): void;
//# sourceMappingURL=../../../../../src/js/utils/error/error/error.d.ts.map