/**
 * Empties the array.
 *
 * @param array - A array to empty.
 */
export declare function empty(array: any[]): void;
//# sourceMappingURL=../../../../../src/js/utils/array/empty/empty.d.ts.map