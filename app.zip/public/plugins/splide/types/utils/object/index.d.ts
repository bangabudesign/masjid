export { assign } from './assign/assign';
export { forOwn } from './forOwn/forOwn';
export { merge } from './merge/merge';
//# sourceMappingURL=../../../../src/js/utils/object/index.d.ts.map