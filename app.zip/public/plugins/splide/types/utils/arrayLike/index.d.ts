export { slice } from './slice/slice';
export { find } from './find/find';
//# sourceMappingURL=../../../../src/js/utils/arrayLike/index.d.ts.map