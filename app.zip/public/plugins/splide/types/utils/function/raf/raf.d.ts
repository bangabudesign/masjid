/**
 * The arias of `window.requestAnimationFrame()`.
 */
export declare function raf(func: FrameRequestCallback): number;
//# sourceMappingURL=../../../../../src/js/utils/function/raf/raf.d.ts.map