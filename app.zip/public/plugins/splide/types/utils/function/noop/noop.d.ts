/**
 * No operation.
 */
export declare const noop: () => void;
//# sourceMappingURL=../../../../../src/js/utils/function/noop/noop.d.ts.map