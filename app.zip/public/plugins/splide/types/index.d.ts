export { Splide } from './core/Splide/Splide';
export { Splide as default } from './core/Splide/Splide';
export { SplideRenderer } from './renderer/SplideRenderer/SplideRenderer';
export * from './constructors';
export * from './types';
export * from './constants/events';
export * from './constants/classes';
//# sourceMappingURL=../../src/js/index.d.ts.map