/**
 * The dummy url.
 */
export declare const URL = "https://test.com";
/**
 * The root and track width.
 */
export declare const SLIDER_WIDTH = 1280;
//# sourceMappingURL=../../../../src/js/test/fixtures/constants.d.ts.map