export * from './html';
//# sourceMappingURL=../../../../src/js/test/fixtures/index.d.ts.map