/**
 * Enumerates slides from left to right.
 */
export declare const LTR = "ltr";
/**
 * Enumerates slides from right to left.
 */
export declare const RTL = "rtl";
/**
 * Enumerates slides in a col.
 */
export declare const TTB = "ttb";
//# sourceMappingURL=../../../src/js/constants/directions.d.ts.map