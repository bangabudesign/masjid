import { Options } from '../types';
/**
 * The collection of default options.
 * Note that this collection does not contain all options.
 *
 * @since 3.0.0
 */
export declare const DEFAULTS: Options;
//# sourceMappingURL=../../../src/js/constants/defaults.d.ts.map