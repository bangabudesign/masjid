/**
 * The project code.
 *
 * @since 3.0.0
 */
export declare const PROJECT_CODE = "splide";
/**
 * The data attribute prefix.
 *
 * @since 3.0.0
 */
export declare const DATA_ATTRIBUTE: string;
//# sourceMappingURL=../../../src/js/constants/project.d.ts.map