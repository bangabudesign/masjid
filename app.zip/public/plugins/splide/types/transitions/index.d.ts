export { Fade } from './Fade/Fade';
export { Slide } from './Slide/Slide';
//# sourceMappingURL=../../../src/js/transitions/index.d.ts.map