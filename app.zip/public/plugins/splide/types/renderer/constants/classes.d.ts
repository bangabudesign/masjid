export declare const CLASS_RENDERED = "is-rendered";
//# sourceMappingURL=../../../../src/js/renderer/constants/classes.d.ts.map