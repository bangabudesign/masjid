<footer class="footer">
    <div class="container">
        <p class="text-center mb-0">All right reserved © <a href="{{ config('app.url', 'https://localhost') }}">{{ config('app.domain', 'localhost') }}</a> 2021</p>
    </div>
</footer>